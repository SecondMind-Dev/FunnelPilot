"""Connector facade for FunnelPilot."""

from __future__ import annotations

from loguru import logger

from ..schemas.models import ChannelEvent, Segment
from . import hubspot, pipedrive, salesforce


def collect_segments() -> list[Segment]:
    """Aggregate segment data from every configured CRM."""

    segments: list[Segment] = []
    segments.extend(hubspot.fetch_segments())
    segments.extend(salesforce.fetch_segments())
    segments.extend(pipedrive.fetch_segments())

    logger.debug("Collected %s segments across CRMs", len(segments))
    return segments


def dispatch_channel_events(events: list[ChannelEvent]) -> None:
    """Fan out events to connector-specific loggers."""

    for event in events:
        if event.channel.value == "email":
            hubspot.log_event(event)
        elif event.channel.value == "linkedin":
            pipedrive.log_event(event)
        else:
            salesforce.log_event(event)


__all__ = ["collect_segments", "dispatch_channel_events"]
