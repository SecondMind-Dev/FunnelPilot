"""Pipedrive connector for FunnelPilot."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import httpx
from loguru import logger

from ..schemas.models import ChannelEvent, Segment
from ..utils.store import load_json

API_BASE = "https://api.pipedrive.com/v1"


def fetch_segments(api_token: str | None = None) -> list[Segment]:
    """Retrieve segments (filters) from Pipedrive."""

    token = api_token or os.getenv("PIPEDRIVE_API_KEY")
    if not token:
        logger.debug("No Pipedrive API token; falling back to sample data")
        return _sample_segments()

    try:
        response = httpx.get(
            f"{API_BASE}/filters",
            params={"api_token": token, "type": "person"},
            timeout=10.0,
        )
        response.raise_for_status()
        data = response.json().get("data", [])
        segments: list[Segment] = []
        for row in data:
            segments.append(
                Segment(
                    id=str(row.get("id")),
                    name=row.get("name", "Pipedrive Filter"),
                    crm="pipedrive",
                    description=row.get("desc", "Pipedrive smart filter"),
                    persona=row.get("category", "growth"),
                    size=int(row.get("item_count", 0)),
                    filters={"type": row.get("type", "person")},
                    last_synced=datetime.now(timezone.utc),
                )
            )
        return segments or _sample_segments()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Pipedrive filter fetch failed: %s", exc)
        return _sample_segments()


def log_event(event: ChannelEvent) -> None:
    """Record an engagement event for analytics."""

    logger.debug("Appending Pipedrive engagement for %s", event.recipient)
    cache = load_json("channel_logs.json", default=[])
    cache.append({
        "source": "pipedrive",
        "campaign": event.campaign_id,
        "recipient": event.recipient,
        "channel": event.channel.value,
        "status": event.status,
        "timestamp": event.sent_at.isoformat(),
    })


def _sample_segments() -> list[Segment]:
    payload = load_json("segments.json", default=[])
    return [
        Segment(
            id=item["id"],
            name=item["name"],
            crm="pipedrive",
            description=item.get("description", ""),
            persona=item.get("persona", "growth"),
            size=int(item.get("size", 0)),
            filters=item.get("filters", {}),
            last_synced=datetime.fromisoformat(item.get("last_synced")),
        )
        for item in payload
        if item.get("crm") == "pipedrive"
    ]


__all__ = ["fetch_segments", "log_event"]
