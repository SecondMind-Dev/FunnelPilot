"""Salesforce connector for FunnelPilot."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import httpx
from loguru import logger

from ..schemas.models import ChannelEvent, Segment
from ..utils.store import load_json


def fetch_segments(instance_url: str | None = None, access_token: str | None = None) -> list[Segment]:
    """Fetch segments from Salesforce Marketing Cloud, with graceful fallback."""

    token = access_token or os.getenv("SALESFORCE_API_KEY") or os.getenv("SALESFORCE_ACCESS_TOKEN")
    instance = instance_url or os.getenv("SALESFORCE_INSTANCE_URL")

    if not token or not instance:
        logger.debug("Salesforce credentials missing; using local segment data")
        return _sample_segments()

    query = (
        "SELECT Id, Name, Description, LastModifiedDate, NumberOfMembers, Persona__c "
        "FROM Campaign WHERE Status != 'Completed' LIMIT 10"
    )

    try:
        response = httpx.get(
            f"{instance}/services/data/v57.0/query",
            params={"q": query},
            headers={"Authorization": f"Bearer {token}"},
            timeout=10.0,
        )
        response.raise_for_status()
        records = response.json().get("records", [])
        segments: list[Segment] = []
        for record in records:
            segments.append(
                Segment(
                    id=record.get("Id", "sf-campaign"),
                    name=record.get("Name", "Salesforce Campaign"),
                    crm="salesforce",
                    description=record.get("Description", "Salesforce campaign"),
                    persona=record.get("Persona__c", "sales"),
                    size=int(record.get("NumberOfMembers", 0)),
                    filters={"status": record.get("Status", "Draft")},
                    last_synced=datetime.now(timezone.utc),
                )
            )
        return segments or _sample_segments()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Salesforce segment fetch failed: %s", exc)
        return _sample_segments()


def log_event(event: ChannelEvent) -> None:
    """Simulate writing campaign engagement back into Salesforce."""

    logger.debug("Logging Salesforce event for %s", event.recipient)
    cache = load_json("channel_logs.json", default=[])
    cache.append({
        "source": "salesforce",
        "campaign": event.campaign_id,
        "recipient": event.recipient,
        "channel": event.channel.value,
        "status": event.status,
        "timestamp": event.sent_at.isoformat(),
    })


def _sample_segments() -> list[Segment]:
    payload = load_json("segments.json", default=[])
    segments: list[Segment] = []
    for item in payload:
        if item.get("crm") != "salesforce":
            continue
        segments.append(
            Segment(
                id=item["id"],
                name=item["name"],
                crm="salesforce",
                description=item.get("description", ""),
                persona=item.get("persona", "sales"),
                size=int(item.get("size", 0)),
                filters=item.get("filters", {}),
                last_synced=datetime.fromisoformat(item.get("last_synced")),
            )
        )
    return segments


__all__ = ["fetch_segments", "log_event"]
