"""HubSpot connector stubs for FunnelPilot."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import httpx
from loguru import logger

from ..schemas.models import ChannelEvent, Segment
from ..utils.store import load_json

API_BASE = "https://api.hubapi.com"


def fetch_segments(api_key: str | None = None) -> list[Segment]:
    """Fetch audience segments from HubSpot or fall back to sample data."""

    token = api_key or os.getenv("HUBSPOT_API_KEY")
    if not token:
        logger.debug("No HubSpot token; using sample data")
        return _sample_segments()

    try:
        response = httpx.get(
            f"{API_BASE}/crm/v3/objects/lists",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10.0,
        )
        response.raise_for_status()
        records = response.json().get("results", [])
        segments: list[Segment] = []
        for row in records:
            properties = row.get("properties", {})
            segments.append(
                Segment(
                    id=str(row.get("id")),
                    name=properties.get("name", "HubSpot Segment"),
                    crm="hubspot",
                    description=properties.get("description", "HubSpot smart list"),
                    persona=properties.get("persona", "growth"),
                    size=int(properties.get("memberCount", 0)),
                    filters={"hs_list_type": properties.get("listType", "STATIC")},
                    last_synced=datetime.now(timezone.utc),
                )
            )
        return segments or _sample_segments()
    except Exception as exc:  # noqa: BLE001
        logger.warning("HubSpot segment fetch failed, falling back to samples: %s", exc)
        return _sample_segments()


def log_event(event: ChannelEvent) -> None:
    """Pretend to post engagement back into HubSpot."""

    logger.debug("Recording HubSpot engagement for %s", event.recipient)
    cache = load_json("channel_logs.json", default=[])
    cache.append({
        "source": "hubspot",
        "campaign": event.campaign_id,
        "recipient": event.recipient,
        "channel": event.channel.value,
        "status": event.status,
        "timestamp": event.sent_at.isoformat(),
    })


def _sample_segments() -> list[Segment]:
    payload = load_json("segments.json", default=[])
    segments: list[Segment] = []
    for item in payload:
        if item.get("crm") != "hubspot":
            continue
        segments.append(
            Segment(
                id=item["id"],
                name=item["name"],
                crm="hubspot",
                description=item.get("description", ""),
                persona=item.get("persona", "growth"),
                size=int(item.get("size", 0)),
                filters=item.get("filters", {}),
                contacts=item.get("contacts", []),
                last_synced=datetime.fromisoformat(item.get("last_synced")),
            )
        )
    return segments


__all__ = ["fetch_segments", "log_event"]
