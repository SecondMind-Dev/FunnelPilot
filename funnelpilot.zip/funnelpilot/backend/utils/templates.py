"""Message template helpers and AI copy assist wrappers."""

from __future__ import annotations

import os
from datetime import datetime
from random import choice
from typing import Any

import httpx
from loguru import logger

from ..schemas.models import Channel, CopySuggestion, SequenceStep
from .store import BASE_PATH, load_json, write_json


_TEMPLATE_CACHE: dict[str, list[dict[str, Any]]] = {}


def load_templates() -> dict[str, list[dict[str, Any]]]:
    """Load channel templates from the data directory, cached in memory."""

    if _TEMPLATE_CACHE:
        return _TEMPLATE_CACHE

    payload = load_json("templates.json", default=[])
    grouped: dict[str, list[dict[str, Any]]] = {}
    for item in payload:
        grouped.setdefault(item.get("channel", "email"), []).append(item)
    _TEMPLATE_CACHE.update(grouped)
    return grouped


def pick_template(channel: Channel, persona: str) -> SequenceStep:
    """Return a SequenceStep assembled from template metadata."""

    options = load_templates().get(channel.value, [])
    if not options:
        logger.debug("No templates for %s, using fallback copy", channel)
        return SequenceStep(
            order=1,
            channel=channel,
            subject="Let's collaborate",
            body=f"Hey {persona} team — backing you with a smarter playbook.",
            send_offset_hours=0,
        )

    pick = choice(options)
    return SequenceStep(
        order=pick.get("order", 1),
        channel=channel,
        subject=pick.get("subject"),
        body=pick.get("body", ""),
        send_offset_hours=pick.get("send_offset_hours", 0),
        call_to_action=pick.get("call_to_action"),
    )


def ai_suggest_copy(prompt: str, *, tone: str = "professional") -> CopySuggestion:
    """Generate AI-assisted copy via OpenAI if configured, else fallback copy."""

    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("FUNNELPILOT_COPY_MODEL", "gpt-4o-mini")
    if not api_key:
        logger.info("OPENAI_API_KEY missing; returning deterministic copy suggestion")
        sanitized_prompt = ' '.join(prompt.split())
        sanitized_prompt = sanitized_prompt.replace('DROP', '').replace('drop', '')
        summary = sanitized_prompt[:140] or "Let's build momentum"
        return CopySuggestion(
            body=f"[{tone.title()} tone] {summary}... Let's sync this week?",
            tone=tone,
            model="funnelpilot-fallback",
            latency_ms=3,
        )

    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are a marketing automation strategist. Write concise outreach copy.",
            },
            {"role": "user", "content": f"Tone: {tone}\nPrompt: {prompt}"},
        ],
        "temperature": 0.7,
        "max_tokens": 180,
    }
    start = datetime.utcnow()

    try:
        response = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=15.0,
        )
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"].strip()
        latency = int((datetime.utcnow() - start).total_seconds() * 1000)
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        subject = lines[0] if lines else None
        body = "\n".join(lines[1:]) if len(lines) > 1 else content
        suggestion = CopySuggestion(subject=subject, body=body, tone=tone, model=model, latency_ms=latency)
        cache_ai_suggestion(suggestion)
        return suggestion
    except Exception as exc:  # noqa: BLE001
        logger.warning("AI copy suggestion failed: %s", exc)
        return CopySuggestion(
            subject=None,
            body=f"[{tone.title()} tone fallback] {prompt[:140]}...",
            tone=tone,
            model="funnelpilot-error",
            latency_ms=int((datetime.utcnow() - start).total_seconds() * 1000),
        )


def cache_ai_suggestion(suggestion: CopySuggestion) -> None:
    """Persist AI output to allow deterministic tests."""

    cache = load_json("ai_copy_cache.json", default=[])
    cache.append(suggestion.model_dump())
    write_json("ai_copy_cache.json", cache)


__all__ = ["load_templates", "pick_template", "ai_suggest_copy", "cache_ai_suggestion"]
