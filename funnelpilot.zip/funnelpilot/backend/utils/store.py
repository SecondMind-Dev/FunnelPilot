"""Utility helpers to read and persist FunnelPilot data artifacts."""

from __future__ import annotations

import json
from pathlib import Path
from threading import Lock
from typing import Any

from loguru import logger

BASE_PATH = Path(__file__).resolve().parents[2] / "data"
_LOCKS: dict[Path, Lock] = {}


def _lock_for(path: Path) -> Lock:
    lock = _LOCKS.get(path)
    if lock is None:
        lock = Lock()
        _LOCKS[path] = lock
    return lock


def load_json(name: str, default: Any) -> Any:
    """Load JSON file under data/ with a default."""

    path = BASE_PATH / name
    if not path.exists():
        logger.debug("Creating missing data artifact %s", path)
        path.write_text(json.dumps(default, indent=2))
        return default

    with _lock_for(path):
        try:
            raw = path.read_text()
            return json.loads(raw) if raw.strip() else default
        except json.JSONDecodeError as exc:
            logger.warning("Could not decode %s, returning default: %s", path, exc)
            return default


def write_json(name: str, payload: Any) -> None:
    """Persist JSON payload atomically."""

    path = BASE_PATH / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with _lock_for(path):
        tmp_path = path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(payload, indent=2, default=str))
        tmp_path.replace(path)


__all__ = ["load_json", "write_json", "BASE_PATH"]
