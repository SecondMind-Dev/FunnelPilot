"""Webhook and channel notifier utilities."""

from __future__ import annotations

import os
from typing import Iterable

import httpx
from loguru import logger

from ..schemas.models import CampaignPlan, ChannelEvent


def send_slack_digest(plan: CampaignPlan, events: Iterable[ChannelEvent]) -> None:
    """Send a digest of a campaign launch to Slack if configured."""

    webhook = os.getenv("SLACK_WEBHOOK_URL")
    if not webhook:
        logger.debug("SLACK_WEBHOOK_URL not set; skipping Slack digest")
        return

    lines = [
        f"Campaign *{plan.name}* launched",
        f"Segment: {plan.segment_id} · Steps: {len(plan.steps)}",
    ]
    sample = list(events)[:5]
    for event in sample:
        lines.append(
            f"• {event.channel.value.title()} → {event.recipient} ({event.status})"
        )

    payload = {"text": "\n".join(lines)}

    try:
        response = httpx.post(webhook, json=payload, timeout=8.0)
        response.raise_for_status()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Slack digest failed: %s", exc)


def send_linkedin_simulation(event: ChannelEvent) -> None:
    """Simulate a LinkedIn DM send (logged to console)."""

    logger.info("LinkedIn DM → %s: %s", event.recipient, event.body_preview)


__all__ = ["send_slack_digest", "send_linkedin_simulation"]
