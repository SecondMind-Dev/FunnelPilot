"""Standalone heuristics used by the strategy engine."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..schemas.models import CampaignMetrics


@dataclass
class HeuristicDecision:
    """Represents a single heuristic adjustment."""

    code: str
    title: str
    detail: str
    intensity: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "title": self.title,
            "detail": self.detail,
            "intensity": self.intensity,
        }


def fatigue_guard(metrics: CampaignMetrics, profile: dict[str, Any]) -> HeuristicDecision | None:
    fatigue_threshold = profile.get("fatigue_threshold", 0.62)
    cadence_shift = profile.get("fatigue_cadence_shift", 6)
    fatigue_score = max(0.0, min(1.0, 1 - metrics.open_rate))
    if fatigue_score >= fatigue_threshold:
        detail = (
            f"Open rate dropped to {metrics.open_rate:.0%}. "
            f"Delaying next LinkedIn steps by {cadence_shift}h to cool the list."
        )
        return HeuristicDecision(
            code="cadence_delay",
            title="Audience cooling",
            detail=detail,
            intensity=fatigue_score,
        )
    return None


def momentum_boost(metrics: CampaignMetrics, profile: dict[str, Any]) -> HeuristicDecision | None:
    boost_floor = profile.get("momentum_floor", 0.18)
    boost_bonus = profile.get("momentum_bonus", 4)
    if metrics.reply_rate >= boost_floor:
        detail = (
            f"Reply rate at {metrics.reply_rate:.0%}. "
            f"Front-loading step 2 by {boost_bonus}h to ride the streak."
        )
        return HeuristicDecision(
            code="cadence_accelerate",
            title="Momentum push",
            detail=detail,
            intensity=metrics.reply_rate,
        )
    return None


def deliverability_watch(metrics: CampaignMetrics, timeline_count: int, profile: dict[str, Any]) -> HeuristicDecision | None:
    ceiling = profile.get("deliverability_events_ceiling", 12)
    risk = timeline_count / max(ceiling, 1)
    if risk >= 1:
        detail = (
            "High outbound volume in last sprint. Switching final step to SMS to reduce inbox load."
        )
        return HeuristicDecision(
            code="channel_shift",
            title="Deliverability reroute",
            detail=detail,
            intensity=min(1.0, risk),
        )
    return None


RULES = (fatigue_guard, momentum_boost, deliverability_watch)


__all__ = ["RULES", "HeuristicDecision"]
