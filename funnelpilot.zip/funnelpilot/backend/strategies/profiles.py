"""Profile loader for heuristic strategies."""

from __future__ import annotations

from functools import lru_cache
from typing import Any

from ..utils.store import load_json

PROFILES_FILE = "heuristic_profiles.json"


@lru_cache(maxsize=1)
def load_profiles() -> dict[str, Any]:
    """Load heuristic configuration."""

    payload = load_json(PROFILES_FILE, default=[])
    indexed: dict[str, Any] = {}
    for item in payload:
        key = item.get("id", "default")
        indexed[key] = item
    return indexed


def profile_for_persona(persona: str) -> dict[str, Any]:
    profiles = load_profiles()
    return profiles.get(persona.lower(), profiles.get("default", {}))


__all__ = ["load_profiles", "profile_for_persona"]
