"""Evaluate heuristic rules and compose narrative decisions."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from loguru import logger

from ..schemas.models import CampaignMetrics
from ..utils.store import load_json
from .profiles import profile_for_persona
from .rules import RULES, HeuristicDecision

MISSION_FILE = "mission_events.json"


def evaluate_playbook(
    *,
    metrics: CampaignMetrics,
    persona: str,
    campaign_id: str,
) -> list[dict[str, Any]]:
    """Run heuristics for a persona and return decision payloads."""

    profile = profile_for_persona(persona)
    timeline = load_json(MISSION_FILE, default=[])
    decisions: list[HeuristicDecision] = []

    for rule in RULES:
        try:
            decision = rule(metrics, profile)
            if decision is None:
                continue
            decisions.append(decision)
        except TypeError:
            # Some rules need extra context; retry with timeline count
            decision = rule(metrics, len(timeline), profile)  # type: ignore[arg-type]
            if decision:
                decisions.append(decision)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Heuristic %s failed: %s", rule.__name__, exc)

    now = datetime.now(timezone.utc).isoformat()
    payload = [
        {
            "id": f"{campaign_id}-{decision.code}-{index}",
            "campaign_id": campaign_id,
            "persona": persona,
            "decision": decision.to_dict(),
            "timestamp": now,
        }
        for index, decision in enumerate(decisions)
    ]
    return payload


__all__ = ["evaluate_playbook"]
