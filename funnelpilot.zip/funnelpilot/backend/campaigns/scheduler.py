"""Scheduler that keeps campaigns firing on cadence."""

from __future__ import annotations

import os
from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from loguru import logger

from ..schemas.models import CampaignPlan
from ..services.delivery import launch_campaign
from ..utils.store import load_json, write_json

SCHEDULE_FILE = "schedule.json"

_scheduler: AsyncIOScheduler | None = None


def start_scheduler() -> None:
    """Start the APScheduler loop if not already running."""

    global _scheduler
    if _scheduler and _scheduler.running:  # pragma: no cover - defensive
        return

    interval_hours = int(os.getenv("FUNNELPILOT_INTERVAL_HOURS", "6"))
    scheduler = AsyncIOScheduler()
    scheduler.add_job(_dispatch_due_campaigns, IntervalTrigger(hours=interval_hours))
    scheduler.start()
    _scheduler = scheduler
    logger.info("FunnelPilot scheduler started (every %s h)", interval_hours)


def stop_scheduler() -> None:
    """Shut down the scheduler gracefully."""

    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("FunnelPilot scheduler stopped")
    _scheduler = None


def schedule_campaign(plan: CampaignPlan) -> None:
    """Persist a campaign into the cadence file for the scheduler."""

    payload = load_json(SCHEDULE_FILE, default=[])
    payload = [item for item in payload if item.get("id") != plan.id]
    payload.append(plan.model_dump())
    write_json(SCHEDULE_FILE, payload)


def scheduled_campaigns() -> list[CampaignPlan]:
    """Return stored scheduled campaigns."""

    payload = load_json(SCHEDULE_FILE, default=[])
    return [CampaignPlan.model_validate(item) for item in payload]


def _dispatch_due_campaigns() -> None:
    payload = load_json(SCHEDULE_FILE, default=[])
    updated: list[dict] = []
    for item in payload:
        plan = CampaignPlan.model_validate(item)
        due = plan.scheduled_for and plan.scheduled_for <= datetime.now(timezone.utc)
        if due and plan.status in {"scheduled", "draft"}:
            logger.info("Launching scheduled campaign %s", plan.id)
            launch_campaign(plan)
            item["status"] = "launched"
            item["updated_at"] = datetime.now(timezone.utc).isoformat()
        updated.append(item)
    write_json(SCHEDULE_FILE, updated)


__all__ = ["start_scheduler", "stop_scheduler", "schedule_campaign", "scheduled_campaigns"]
