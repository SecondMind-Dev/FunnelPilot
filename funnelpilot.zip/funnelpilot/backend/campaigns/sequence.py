"""Sequence builder for FunnelPilot."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from ..schemas.models import CampaignPlan, Segment, SequenceStep, Channel
from ..utils.templates import pick_template


DEFAULT_CHANNEL_FLOW = [Channel.EMAIL, Channel.LINKEDIN, Channel.SMS]


def build_campaign_plan(segment: Segment, *, owner: str, goal: str, ai_assist: bool = False) -> CampaignPlan:
    """Generate a campaign plan for a given segment."""

    steps: list[SequenceStep] = []
    for order, channel in enumerate(DEFAULT_CHANNEL_FLOW, start=1):
        template = pick_template(channel, segment.persona)
        steps.append(
            SequenceStep(
                order=order,
                channel=channel,
                subject=template.subject,
                body=template.body,
                send_offset_hours=template.send_offset_hours + (order - 1) * 12,
                call_to_action=template.call_to_action,
            )
        )

    now = datetime.now(timezone.utc)
    plan = CampaignPlan(
        id=f"cmp-{uuid4().hex[:8]}",
        name=f"{segment.name} Playbook",
        segment_id=segment.id,
        owner=owner,
        goal=goal,
        status="scheduled" if ai_assist else "draft",
        scheduled_for=now if ai_assist else None,
        created_at=now,
        updated_at=now,
        steps=steps,
        ai_assist_enabled=ai_assist,
    )
    return plan


__all__ = ["build_campaign_plan", "DEFAULT_CHANNEL_FLOW"]
