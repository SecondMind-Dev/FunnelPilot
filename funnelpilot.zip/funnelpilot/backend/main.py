"""FastAPI entrypoint for FunnelPilot."""

from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .campaigns.scheduler import (
    schedule_campaign,
    scheduled_campaigns,
    start_scheduler,
    stop_scheduler,
)
from .campaigns.sequence import build_campaign_plan
from .schemas.models import (
    CampaignPlan,
    Channel,
    ChannelEvent,
    CopySuggestion,
    HealthStatus,
    Segment,
)
from .services.analytics import compute_metrics, historical_kpis, load_runs
from .services.delivery import launch_campaign
from .services.heuristics import mission_feed
from .services.segmentation import (
    attach_segments_to_plan,
    hydrate_segment,
    list_segments,
    persist_segments_snapshot,
)
from .utils.templates import ai_suggest_copy
from .utils.store import load_json

app = FastAPI(title="FunnelPilot", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)


class CampaignCreateRequest(BaseModel):
    segment_id: str
    owner: str = "Growth Ops"
    goal: str = "Book demos"
    ai_assist_enabled: bool = False


class LaunchRequest(BaseModel):
    use_ai: bool = Field(default=False)


class CopyPrompt(BaseModel):
    prompt: str
    tone: str = "professional"


@app.on_event("startup")
async def _startup() -> None:
    segments = list_segments()
    persist_segments_snapshot(segments)
    if _env_truthy("FUNNELPILOT_ENABLE_SCHEDULER", default="1"):
        start_scheduler()


@app.on_event("shutdown")
async def _shutdown() -> None:
    stop_scheduler()


@app.get("/health", response_model=HealthStatus)
def health() -> HealthStatus:
    """Return service health payload."""

    segments = list_segments()
    payload = HealthStatus(
        status="ok",
        timestamp=datetime.now(timezone.utc),
        scheduler_up=_env_truthy("FUNNELPILOT_ENABLE_SCHEDULER", default="1"),
        pending_campaigns=len([plan for plan in scheduled_campaigns() if plan.status != "launched"]),
        active_connectors=sorted({segment.crm for segment in segments}),
        docs_url="https://secondmind.dev/funnelpilot",
    )
    return payload


@app.get("/segments", response_model=list[Segment])
def get_segments(persona: str | None = None) -> list[Segment]:
    return list_segments(persona=persona)


@app.post("/campaigns", response_model=CampaignPlan)
def create_campaign(request: CampaignCreateRequest) -> CampaignPlan:
    segment = hydrate_segment(request.segment_id)
    if not segment:
        raise HTTPException(status_code=404, detail="Segment not found")

    plan = build_campaign_plan(
        segment,
        owner=request.owner,
        goal=request.goal,
        ai_assist=request.ai_assist_enabled,
    )
    schedule_campaign(plan)
    return attach_segments_to_plan(plan)


@app.get("/campaigns", response_model=list[CampaignPlan])
def list_campaigns() -> list[CampaignPlan]:
    return [attach_segments_to_plan(plan) for plan in scheduled_campaigns()]


@app.post("/campaigns/{campaign_id}/launch")
def launch(campaign_id: str, payload: LaunchRequest) -> dict[str, Any]:
    plans = {plan.id: plan for plan in scheduled_campaigns()}
    plan = plans.get(campaign_id)
    if not plan:
        raise HTTPException(status_code=404, detail="Campaign not scheduled")

    plan.ai_assist_enabled = payload.use_ai
    plan.status = "launched"
    plan.updated_at = datetime.now(timezone.utc)
    result = launch_campaign(plan)
    schedule_campaign(plan)
    return {
        "status": "ok",
        "metrics": result["metrics"],
        "events": result["events"],
        "decisions": result.get("decisions", []),
    }


@app.post("/copy/suggest", response_model=CopySuggestion)
def suggest_copy(prompt: CopyPrompt) -> CopySuggestion:
    return ai_suggest_copy(prompt.prompt, tone=prompt.tone)


@app.get("/analytics/kpis", response_model=list[dict[str, Any]])
def analytics() -> list[dict[str, Any]]:
    runs = load_runs()
    metrics = historical_kpis()
    timeline = load_json("channel_logs.json", default=[])
    decisions = mission_feed(None)
    return [
        {
            "runs": [run.model_dump() for run in runs],
            "metrics": [metric.model_dump() for metric in metrics],
            "timeline": timeline[-150:],
            "decisions": decisions[-50:],
        }
    ]


@app.get("/mission-events")
def get_mission_events(since: str | None = None) -> list[dict[str, object]]:
    boundary = None
    if since:
        try:
            boundary = datetime.fromisoformat(since)
        except ValueError:
            boundary = None
    return mission_feed(boundary)


@app.get("/timeline", response_model=list[dict[str, Any]])
def timeline() -> list[dict[str, Any]]:
    return load_json("channel_logs.json", default=[])


def _env_truthy(key: str, default: str = "0") -> bool:
    value = os.getenv(key, default).lower().strip()
    return value in {"1", "true", "yes", "on"}


__all__ = ["app"]
