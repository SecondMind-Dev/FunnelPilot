"""Pydantic schema definitions for FunnelPilot."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, HttpUrl


class Channel(str, Enum):
    """Supported orchestration channels."""

    EMAIL = "email"
    LINKEDIN = "linkedin"
    SMS = "sms"
    SLACK = "slack"


class Segment(BaseModel):
    """CRM segment definition fetched from a connector."""

    id: str
    name: str
    crm: Literal["hubspot", "salesforce", "pipedrive"]
    description: str
    persona: str
    size: int = Field(ge=0)
    filters: dict[str, str]
    contacts: list[dict[str, str]] = Field(default_factory=list)
    last_synced: datetime


class SequenceStep(BaseModel):
    """Single step within a multi-channel sequence."""

    order: int = Field(ge=1)
    channel: Channel
    subject: str | None = None
    body: str
    send_offset_hours: int = Field(default=0, ge=0)
    call_to_action: str | None = None


class CampaignPlan(BaseModel):
    """Campaign plan created on the dashboard."""

    id: str
    name: str
    segment_id: str
    owner: str
    goal: str
    status: Literal["draft", "scheduled", "launched", "completed"] = "draft"
    scheduled_for: datetime | None = None
    created_at: datetime
    updated_at: datetime
    steps: list[SequenceStep]
    ai_assist_enabled: bool = False
    segment: dict[str, Any] | None = None


class CampaignRun(BaseModel):
    """Snapshot of a launched campaign."""

    campaign_id: str
    started_at: datetime
    completed_at: datetime | None = None
    delivered: int = 0
    responses: int = 0
    conversions: int = 0
    revenue: float = 0.0
    notes: str | None = None


class ChannelEvent(BaseModel):
    """Event emitted when a channel delivery occurs."""

    campaign_id: str
    segment_id: str
    channel: Channel
    recipient: str
    subject: str | None = None
    body_preview: str
    sent_at: datetime
    status: Literal["queued", "sent", "opened", "replied"] = "queued"
    metadata: dict[str, str] = Field(default_factory=dict)


class CampaignMetrics(BaseModel):
    """KPI snapshot for dashboard cards."""

    campaign_id: str
    total_recipients: int
    open_rate: float
    reply_rate: float
    meetings_booked: int
    influenced_pipeline: float


class CopySuggestion(BaseModel):
    """AI generated copy suggestion for a specific step."""

    subject: str | None = None
    body: str
    tone: Literal["bold", "friendly", "professional", "playful"] = "professional"
    model: str = "mock-gpt"
    latency_ms: int = 0


class HealthStatus(BaseModel):
    """Health check payload."""

    status: Literal["ok", "degraded", "fail"]
    timestamp: datetime
    scheduler_up: bool
    pending_campaigns: int
    active_connectors: list[str]
    docs_url: HttpUrl


__all__ = [
    "CampaignPlan",
    "CampaignRun",
    "CampaignMetrics",
    "Channel",
    "ChannelEvent",
    "CopySuggestion",
    "HealthStatus",
    "Segment",
    "SequenceStep",
]
