"""Glue layer between heuristic engine and data artifacts."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterable

from loguru import logger

from ..schemas.models import CampaignMetrics, CampaignPlan
from ..strategies import evaluate_playbook
from ..utils.store import load_json, write_json
from .segmentation import hydrate_segment

MISSION_FILE = "mission_events.json"


def record_heuristic_actions(
    plan: CampaignPlan,
    metrics: CampaignMetrics,
) -> list[dict[str, object]]:
    """Run heuristics for the plan and store mission events."""

    segment = hydrate_segment(plan.segment_id)
    persona = getattr(segment, "persona", "default") if segment else "default"

    decisions = evaluate_playbook(
        metrics=metrics,
        persona=persona,
        campaign_id=plan.id,
    )
    if not decisions:
        return []

    history = load_json(MISSION_FILE, default=[])
    history.extend(decisions)
    write_json(MISSION_FILE, history)
    logger.debug("Recorded %s heuristic decisions", len(decisions))
    return decisions


def mission_feed(since: datetime | None = None) -> list[dict[str, object]]:
    """Return mission events filtered by timestamp."""

    history = load_json(MISSION_FILE, default=[])
    if since is None:
        return history[-50:]
    boundary = since.replace(tzinfo=timezone.utc)
    results = []
    for item in history:
        ts_raw = item.get("timestamp")
        if not ts_raw:
            continue
        try:
            timestamp = datetime.fromisoformat(ts_raw)
        except ValueError:
            continue
        if timestamp.replace(tzinfo=timezone.utc) >= boundary:
            results.append(item)
    return results


__all__ = ["record_heuristic_actions", "mission_feed"]
