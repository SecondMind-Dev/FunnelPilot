"""Segmentation services bridging CRM connectors and the API."""

from __future__ import annotations

from datetime import datetime
from typing import Iterable

from loguru import logger

from ..connectors import collect_segments
from ..schemas.models import CampaignPlan, Segment
from ..utils.store import load_json, write_json

SEGMENTS_CACHE_FILE = "segments.json"


def list_segments(persona: str | None = None) -> list[Segment]:
    """Return up-to-date segments with optional persona filtering."""

    segments = collect_segments()
    if persona:
        filtered = [segment for segment in segments if segment.persona.lower() == persona.lower()]
        logger.debug("Filtered %s segments for persona %s", len(filtered), persona)
        return filtered

    return segments


def hydrate_segment(segment_id: str) -> Segment | None:
    """Return a specific segment by identifier."""

    for segment in collect_segments():
        if segment.id == segment_id:
            return segment
    return None


def persist_segments_snapshot(segments: Iterable[Segment]) -> None:
    """Persist the current segment objects for offline use."""

    payload = []
    for segment in segments:
        payload.append(
            {
                "id": segment.id,
                "name": segment.name,
                "crm": segment.crm,
                "description": segment.description,
                "persona": segment.persona,
                "size": segment.size,
                "filters": segment.filters,
                "contacts": segment.contacts,
                "last_synced": segment.last_synced.isoformat(),
            }
        )
    write_json(SEGMENTS_CACHE_FILE, payload)


def load_cached_segments() -> list[Segment]:
    """Read the last cached snapshot of segments."""

    payload = load_json(SEGMENTS_CACHE_FILE, default=[])
    results: list[Segment] = []
    for item in payload:
        try:
            results.append(
                Segment(
                    id=item["id"],
                    name=item["name"],
                    crm=item.get("crm", "hubspot"),
                    description=item.get("description", ""),
                    persona=item.get("persona", "growth"),
                    size=int(item.get("size", 0)),
                    filters=item.get("filters", {}),
                    contacts=item.get("contacts", []),
                    last_synced=datetime.fromisoformat(item.get("last_synced")),
                )
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not hydrate cached segment %s: %s", item, exc)
    return results


def attach_segments_to_plan(plan: CampaignPlan) -> CampaignPlan:
    """Return plan enriched with human-readable segment metadata."""

    segment = hydrate_segment(plan.segment_id)
    if not segment:
        return plan

    plan_dict = plan.model_dump()
    plan_dict["segment"] = {
        "name": segment.name,
        "crm": segment.crm,
        "size": segment.size,
        "persona": segment.persona,
    }
    return CampaignPlan.model_validate(plan_dict)


__all__ = [
    "list_segments",
    "hydrate_segment",
    "persist_segments_snapshot",
    "load_cached_segments",
    "attach_segments_to_plan",
]
