"""Analytics helpers for FunnelPilot."""

from __future__ import annotations

from datetime import datetime
from statistics import mean
from typing import Iterable

from loguru import logger

from ..schemas.models import CampaignMetrics, CampaignRun, ChannelEvent
from ..utils.store import load_json, write_json

RUNS_FILE = "campaign_runs.json"


def record_run(run: CampaignRun) -> None:
    """Persist a campaign run into storage."""

    runs = load_json(RUNS_FILE, default=[])
    runs.append(run.model_dump())
    write_json(RUNS_FILE, runs)


def load_runs() -> list[CampaignRun]:
    """Return all stored campaign runs."""

    runs = load_json(RUNS_FILE, default=[])
    results: list[CampaignRun] = []
    for item in runs:
        try:
            results.append(CampaignRun.model_validate(item))
        except Exception as exc:  # noqa: BLE001
            logger.warning("Skipping invalid run entry: %s", exc)
    return results


def compute_metrics(events: Iterable[ChannelEvent], total_recipients: int, campaign_id: str) -> CampaignMetrics:
    """Derive KPI metrics for the dashboard cards."""

    events = list(events)
    opens = sum(1 for event in events if event.status in {"opened", "replied"})
    replies = sum(1 for event in events if event.status == "replied")
    meetings = sum(1 for event in events if event.metadata.get("meeting") == "booked")
    revenue = sum(float(event.metadata.get("influence", 0)) for event in events)

    total = max(total_recipients, 1)
    open_rate = round(opens / total, 3)
    reply_rate = round(replies / total, 3)

    return CampaignMetrics(
        campaign_id=campaign_id,
        total_recipients=total_recipients,
        open_rate=open_rate,
        reply_rate=reply_rate,
        meetings_booked=meetings,
        influenced_pipeline=round(revenue, 2),
    )


def historical_kpis() -> list[CampaignMetrics]:
    """Return stored KPI summaries from past runs for charting."""

    payload = load_json("campaign_runs.json", default=[])
    metrics: list[CampaignMetrics] = []
    for item in payload:
        total = item.get("delivered", 0)
        open_rate = item.get("opens", 0) / max(total, 1)
        reply_rate = item.get("responses", 0) / max(total, 1)
        metrics.append(
            CampaignMetrics(
                campaign_id=item.get("campaign_id", "campaign"),
                total_recipients=total,
                open_rate=round(open_rate, 3),
                reply_rate=round(reply_rate, 3),
                meetings_booked=item.get("meetings", 0),
                influenced_pipeline=round(float(item.get("revenue", 0.0)), 2),
            )
        )
    return metrics


__all__ = ["record_run", "load_runs", "compute_metrics", "historical_kpis"]
