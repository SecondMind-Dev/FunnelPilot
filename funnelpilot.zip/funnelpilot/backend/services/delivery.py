"""Campaign launch orchestration."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Iterable

from loguru import logger

from ..connectors import dispatch_channel_events
from ..schemas.models import CampaignPlan, CampaignRun, Channel, ChannelEvent, SequenceStep
from ..utils.notifier import send_linkedin_simulation, send_slack_digest
from ..utils.templates import ai_suggest_copy
from ..utils.store import load_json, write_json
from .analytics import compute_metrics, record_run
from .heuristics import record_heuristic_actions
from .segmentation import hydrate_segment


def launch_campaign(plan: CampaignPlan, *, recipients: list[dict[str, str]] | None = None) -> dict[str, object]:
    """Launch a campaign plan across configured channels."""

    segment = hydrate_segment(plan.segment_id)
    if not segment:
        msg = f"Segment {plan.segment_id} missing"
        logger.error(msg)
        raise ValueError(msg)

    audience = recipients or segment.contacts
    if not audience:
        sample_contacts = load_json("segments.json", default=[])
        for item in sample_contacts:
            if item.get("id") == plan.segment_id:
                audience = item.get("contacts", [])
                break
    if not audience:
        raise ValueError("No recipients available for campaign launch")

    events: list[ChannelEvent] = []
    now = datetime.now(timezone.utc)
    for index, lead in enumerate(audience):
        for step in plan.steps:
            body = step.body
            subject = step.subject
            if plan.ai_assist_enabled:
                prompt = (
                    f"Write a {step.channel.value} outreach for {lead.get('name', lead.get('email'))} "
                    f"about {plan.goal}."
                )
                suggestion = ai_suggest_copy(prompt, tone="bold")
                body = suggestion.body
                subject = suggestion.subject or subject
            send_time = now + timedelta(hours=step.send_offset_hours, minutes=index * 2)
            recipient = lead.get("email") or lead.get("phone") or lead.get("name") or "contact"
            preview = body[:160]
            events.append(
                ChannelEvent(
                    campaign_id=plan.id,
                    segment_id=plan.segment_id,
                    channel=step.channel,
                    recipient=recipient,
                    subject=subject,
                    body_preview=preview,
                    sent_at=send_time,
                    status="sent",
                    metadata={
                        "contact_name": lead.get("name"),
                        "persona": segment.persona,
                        "meeting": "booked" if index == 0 and step.channel == Channel.EMAIL else "",
                        "influence": "2400" if step.channel == Channel.LINKEDIN and index == 0 else "0",
                    },
                )
            )

    dispatch_channel_events(events)
    for event in events:
        if event.channel == Channel.LINKEDIN:
            send_linkedin_simulation(event)

    send_slack_digest(plan, events)

    metrics = compute_metrics(events, len(audience), plan.id)
    decisions = record_heuristic_actions(plan, metrics)

    run = CampaignRun(
        campaign_id=plan.id,
        started_at=now,
        completed_at=now + timedelta(hours=1),
        delivered=len(events),
        responses=int(metrics.reply_rate * len(audience)),
        conversions=int(metrics.reply_rate * len(audience) * 0.3),
        revenue=metrics.influenced_pipeline,
        notes=f"Auto-launched via FunnelPilot on {now.isoformat()}"
    )
    record_run(run)

    _log_channel_history(events)

    return {
        "campaign": plan.model_dump(),
        "events": [event.model_dump() for event in events],
        "metrics": metrics.model_dump(),
        "decisions": decisions,
    }


def _log_channel_history(events: Iterable[ChannelEvent]) -> None:
    history = load_json("channel_logs.json", default=[])
    for event in events:
        history.append(
            {
                "campaign_id": event.campaign_id,
                "recipient": event.recipient,
                "channel": event.channel.value,
                "status": event.status,
                "timestamp": event.sent_at.isoformat(),
            }
        )
    write_json("channel_logs.json", history)


__all__ = ["launch_campaign"]
