import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: ["./vitest.setup.ts"],
    include: ["src/**/*.test.{js,jsx,ts,tsx}", "tests/components/**/*.test.{js,jsx,ts,tsx}"],
    exclude: ["tests/ui/**", "**/node_modules/**"],
    coverage: {
      enabled: true,
      reporter: ["text", "lcov"],
      exclude: ["tests/ui/**", "**/node_modules/**"],
    },
  },
});
