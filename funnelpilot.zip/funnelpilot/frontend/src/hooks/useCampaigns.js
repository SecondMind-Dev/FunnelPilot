import { useEffect, useMemo, useState } from "react";
import {
  fetchSegments,
  fetchCampaigns,
  createCampaign,
  launchCampaign,
  fetchAnalytics,
  requestCopy,
  fetchTimeline,
  fetchMissionEvents,
} from "../api";

export function useCampaigns() {
  const [segments, setSegments] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [analytics, setAnalytics] = useState({ runs: [], metrics: [], timeline: [], decisions: [] });
  const [missionEvents, setMissionEvents] = useState([]);
  const [error, setError] = useState(null);
  const [missionError, setMissionError] = useState(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const [seg, camp, data, timeline, missions] = await Promise.all([
          fetchSegments(),
          fetchCampaigns(),
          fetchAnalytics(),
          fetchTimeline(),
          fetchMissionEvents(),
        ]);
        setSegments(seg);
        setCampaigns(camp);
        setAnalytics({ ...data, timeline, decisions: missions });
        setMissionEvents(missions);
      } catch (err) {
        const message = err?.message ?? "Failed to load FunnelPilot data";
        setError(message);
        setMissionError(message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  useEffect(() => {
    let cancelled = false;
    const interval = setInterval(async () => {
      try {
        const last = missionEvents[missionEvents.length - 1]?.timestamp;
        const updates = await fetchMissionEvents(last);
        if (cancelled) return;
        if (updates.length) {
          setMissionEvents((prev) => [...prev, ...updates]);
          setAnalytics((prev) => ({
            ...prev,
            decisions: [...(prev.decisions ?? []), ...updates],
          }));
        }
      } catch (err) {
        if (!cancelled) {
          setMissionError(err?.message ?? "Mission feed failed");
        }
      }
    }, 10000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [missionEvents]);

  const metrics = useMemo(() => analytics.metrics ?? [], [analytics.metrics]);

  async function planCampaign(segmentId) {
    const segment = segments.find((seg) => seg.id === segmentId);
    if (!segment) throw new Error("Unknown segment");
    const plan = await createCampaign({ segment_id: segmentId, owner: "Caleb", goal: "Book live demo", ai_assist_enabled: true });
    setCampaigns((prev) => [...prev, plan]);
    return plan;
  }

  async function launch(id) {
    const result = await launchCampaign(id, true);
    const updated = await fetchCampaigns();
    setCampaigns(updated);
    const analyticsPayload = await fetchAnalytics();
    const timeline = await fetchTimeline();
    const missions = await fetchMissionEvents();
    setAnalytics({ ...analyticsPayload, timeline, decisions: missions });
    setMissionEvents(missions);
    return result;
  }

  async function aiCopy(prompt, tone) {
    return requestCopy(prompt, tone);
  }

  return {
    segments,
    campaigns,
    metrics,
    timeline: analytics.timeline ?? [],
    runs: analytics.runs ?? [],
    decisions: analytics.decisions ?? [],
    missionEvents,
    missionError,
    loading,
    error,
    planCampaign,
    launch,
    aiCopy,
  };
}
