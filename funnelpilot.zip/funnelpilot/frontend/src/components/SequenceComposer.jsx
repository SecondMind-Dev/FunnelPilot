import { motion } from "framer-motion";
import { Bot, Wand2 } from "lucide-react";

function SequenceComposer({ campaign, onCopySuggestion }) {
  if (!campaign) {
    return (
      <div className="rounded-3xl border border-slate-700/60 bg-slate-900/60 p-6 text-sm text-slate-400">
        Choose a campaign from the board to reveal its sequence.
      </div>
    );
  }

  return (
    <motion.section
      key={campaign.id}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-slate-700/60 bg-slate-950/70 p-6 backdrop-blur"
    >
      <header className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-slate-400/70">Sequence</p>
          <h2 className="text-xl font-semibold text-slate-50">{campaign.name}</h2>
        </div>
        <button
          className="inline-flex items-center gap-2 rounded-full border border-neon-magenta/40 bg-neon-magenta/10 px-3 py-1 text-xs uppercase tracking-widest text-neon-magenta transition hover:bg-neon-magenta/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-neon-magenta/60 disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={() => onCopySuggestion(campaign)}
          disabled={!campaign}
          type="button"
        >
          <Bot className="h-3 w-3" /> Ask AI
        </button>
      </header>
      <ol className="mt-4 space-y-4">
        {campaign.steps.map((step) => (
          <li
            key={step.order}
            className="rounded-2xl border border-slate-700/60 bg-slate-900/60 p-5 shadow-inner shadow-black/40"
          >
            <div className="flex items-center justify-between text-xs uppercase tracking-widest text-slate-400">
              <span>Step {step.order}</span>
              <span>{step.channel}</span>
            </div>
            <h3 className="mt-2 text-lg font-semibold text-slate-50">{step.subject || "LinkedIn touch"}</h3>
            <p className="mt-2 whitespace-pre-line text-sm text-slate-300/80">{step.body}</p>
            <p className="mt-3 text-xs text-slate-500">Send +{step.send_offset_hours}h · CTA {step.call_to_action || "Follow up"}</p>
          </li>
        ))}
      </ol>
    </motion.section>
  );
}

export default SequenceComposer;
