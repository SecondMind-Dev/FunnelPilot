import { motion } from "framer-motion";
import { Flame, Rocket, Sparkles } from "lucide-react";

function CampaignBoard({ segments, campaigns, onPlan, onLaunch, selectedCampaignId, onSelect, launchingId }) {
  return (
    <div className="space-y-5">
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="rounded-3xl border border-purple-700/40 bg-slate-900/70 p-5 shadow-lg shadow-purple-900/40 backdrop-blur"
      >
        <header className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-purple-200/60">Segments locked</p>
            <h2 className="text-xl font-semibold text-slate-50">Launch pads</h2>
          </div>
          <Sparkles className="h-5 w-5 text-neon-teal" />
        </header>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          {segments.map((segment) => (
            <motion.article
              key={segment.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="group rounded-2xl border border-slate-700/60 bg-slate-950/70 p-4 shadow-inner shadow-black/40 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-neon-teal/60 cursor-pointer"
              onClick={() => onPlan(segment.id)}
              tabIndex={0}
            >
              <p className="text-xs uppercase tracking-widest text-slate-400/80">{segment.crm}</p>
              <h3 className="mt-1 text-lg font-semibold text-slate-50">{segment.name}</h3>
              <p className="mt-1 text-sm text-slate-300/80">{segment.description}</p>
              <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                <span>{segment.size} humans</span>
                <button
                  className="rounded-full border border-neon-teal/60 px-3 py-1 text-neon-teal text-xs uppercase tracking-widest transition group-hover:bg-neon-teal/10 group-active:bg-neon-teal/20"
                  onClick={(event) => {
                    event.stopPropagation();
                    onPlan(segment.id);
                  }}
                >
                  Prime playbook
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="rounded-3xl border border-emerald-600/40 bg-slate-900/60 p-5 shadow-emerald-900/40 backdrop-blur"
      >
        <header className="flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-emerald-200/60">Campaign queue</p>
            <h2 className="text-xl font-semibold text-slate-50">Battleboard</h2>
          </div>
          <Flame className="h-5 w-5 text-emerald-400" />
        </header>
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          {campaigns.map((campaign) => {
            const isSelected = selectedCampaignId === campaign.id;
            return (
              <motion.article
                key={campaign.id}
                onClick={() => onSelect(campaign)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`cursor-pointer rounded-2xl border p-4 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400/70 ${
                  isSelected
                    ? "border-emerald-300/70 bg-emerald-500/10 shadow-lg shadow-emerald-500/30"
                    : "border-slate-700/60 bg-slate-950/50 hover:border-emerald-500/60"
                }`}
                tabIndex={0}
              >
                <header className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-slate-50">{campaign.name}</h3>
                  <span className="rounded-full border border-emerald-400/50 px-2 py-0.5 text-xs uppercase tracking-widest text-emerald-200/80">
                    {campaign.status}
                  </span>
                </header>
                <p className="mt-2 text-sm text-slate-300/80">Goal · {campaign.goal}</p>
                <p className="mt-2 text-xs text-slate-400">Owner · {campaign.owner}</p>
                <button
                  className={`mt-3 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold text-slate-900 transition ${
                    launchingId === campaign.id
                      ? "bg-slate-700 text-slate-300"
                      : "bg-gradient-to-r from-emerald-500/70 to-sky-500/50 hover:from-emerald-400 hover:to-sky-400"
                  }`}
                  disabled={launchingId === campaign.id}
                  onClick={(event) => {
                    event.stopPropagation();
                    onLaunch(campaign.id);
                  }}
                >
                  <Rocket className="h-3 w-3" /> {launchingId === campaign.id ? "Launching" : "Ignite now"}
                </button>
              </motion.article>
            );
          })}
        </div>
      </motion.section>
    </div>
  );
}

export default CampaignBoard;
