import { motion } from "framer-motion";

const hours = ["08", "10", "12", "14", "16", "18", "20", "22"];
const channels = ["email", "linkedin", "sms"];

function ChannelHeatmap({ campaigns }) {
  const matrix = channels.map((channel) =>
    hours.map((hour) => {
      const hits = campaigns.filter((campaign) =>
        campaign.steps.some((step) => step.channel === channel && step.send_offset_hours.toString().padStart(2, "0").startsWith(hour))
      ).length;
      return hits;
    })
  );

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-slate-700/60 bg-slate-900/60 p-6"
    >
      <header className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-slate-400/60">Send Windows</p>
          <h2 className="text-xl font-semibold text-slate-50">Cadence heatmap</h2>
        </div>
      </header>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[320px] border-separate border-spacing-2 text-sm">
          <thead>
            <tr>
              <th className="w-24 text-left text-xs uppercase tracking-widest text-slate-400">Channel</th>
              {hours.map((hour) => (
                <th key={hour} className="text-xs uppercase tracking-widest text-slate-500">
                  {hour}h
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {channels.map((channel, rowIndex) => (
              <tr key={channel}>
                <td className="text-xs uppercase tracking-widest text-slate-400">{channel}</td>
                {hours.map((hour, colIndex) => {
                  const value = matrix[rowIndex][colIndex];
                  const intensity = Math.min(1, value / 3);
                  const bg = `rgba(0, 255, 224, ${0.1 + intensity * 0.45})`;
                  return (
                    <td
                      key={`${channel}-${hour}`}
                      className="h-10 rounded-xl text-center text-sm font-semibold text-slate-900"
                      style={{ background: bg }}
                    >
                      {value ? value : ""}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.section>
  );
}

export default ChannelHeatmap;
