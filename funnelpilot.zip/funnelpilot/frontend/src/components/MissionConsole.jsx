import { motion } from "framer-motion";
import { Activity, Brain, RefreshCcw } from "lucide-react";
import clsx from "clsx";

function MissionConsole({ missions, runs }) {
  const latest = missions.slice(-3).reverse();
  const lastRun = runs[runs.length - 1];

  return (
    <motion.section
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-3xl border border-neon-teal/40 bg-slate-950/70 p-6 backdrop-blur"
    >
      <header className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-neon-teal/70">Mission console</p>
          <h2 className="text-xl font-semibold text-slate-50">Heuristic decisions</h2>
        </div>
        <Brain className="h-5 w-5 text-neon-teal" />
      </header>
      <div className="mt-5 space-y-3">
        {latest.length === 0 && (
          <p className="text-sm text-slate-400">No missions fired yet—ignite a campaign.</p>
        )}
        {latest.map((entry) => (
          <MissionCard key={entry.id} entry={entry} />
        ))}
      </div>
      {lastRun && (
        <div className="mt-6 grid gap-3 md:grid-cols-3 text-xs uppercase tracking-widest text-slate-300/70">
          <MiniStat icon={Activity} label="Last run" value={new Date(lastRun.completed_at ?? lastRun.started_at).toLocaleString()} />
          <MiniStat icon={RefreshCcw} label="Reply rate" value={`${Math.round(lastRun.responses / Math.max(lastRun.delivered, 1) * 100)}%`} />
          <MiniStat icon={Brain} label="Decisions logged" value={missions.length} />
        </div>
      )}
    </motion.section>
  );
}

function MissionCard({ entry }) {
  const { decision } = entry;
  return (
    <motion.article
      initial={{ opacity: 0, x: 12 }}
      animate={{ opacity: 1, x: 0 }}
      className={clsx(
        "rounded-2xl border border-slate-700/60 bg-slate-900/60 p-4 shadow-inner shadow-black/30",
        decision?.code === "cadence_delay" && "border-amber-400/40",
        decision?.code === "cadence_accelerate" && "border-emerald-400/40",
        decision?.code === "channel_shift" && "border-sky-400/40"
      )}
    >
      <p className="text-xs uppercase tracking-widest text-slate-400">{decision?.title ?? "Heuristic"}</p>
      <p className="mt-1 text-sm text-slate-100">{decision?.detail}</p>
      <p className="mt-2 text-[11px] text-slate-400/70">{new Date(entry.timestamp).toLocaleTimeString()}</p>
    </motion.article>
  );
}

function MiniStat({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-2 rounded-2xl border border-slate-800/60 bg-slate-900/50 px-3 py-2">
      <Icon className="h-3.5 w-3.5 text-neon-teal" />
      <div>
        <p>{label}</p>
        <p className="text-slate-200/90 text-[13px] normal-case">{value}</p>
      </div>
    </div>
  );
}

export default MissionConsole;
