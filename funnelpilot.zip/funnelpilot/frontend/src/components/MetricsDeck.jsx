import { motion } from "framer-motion";
import clsx from "clsx";

const palette = [
  "from-neon-teal/30 to-slate-900/80",
  "from-neon-magenta/30 to-slate-900/80",
  "from-neon-royal/30 to-slate-900/80",
];

function MetricsDeck({ metrics }) {
  if (!metrics?.length) {
    return (
      <div className="rounded-3xl border border-slate-700/60 bg-slate-900/60 p-6 text-sm text-slate-400">
        Waiting for the first campaign to fire.
      </div>
    );
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45 }}
      className="rounded-3xl border border-slate-700/60 bg-slate-950/60 p-6 backdrop-blur"
    >
      <header className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-slate-400/70">Telemetry</p>
          <h2 className="text-xl font-semibold text-slate-50">Conversion lift</h2>
        </div>
      </header>
      <div className="mt-5 grid gap-4 md:grid-cols-3">
        {metrics.slice(0, 3).map((metric, index) => (
          <motion.article
            key={metric.campaign_id}
            whileHover={{ scale: 1.02 }}
            className={clsx(
              "rounded-2xl border border-slate-700/60 bg-gradient-to-br p-4 shadow-inner shadow-black/40",
              palette[index % palette.length]
            )}
          >
            <p className="text-xs uppercase tracking-widest text-slate-200/60">{metric.campaign_id}</p>
            <h3 className="mt-1 text-3xl font-semibold text-slate-50">{(metric.reply_rate * 100).toFixed(1)}%</h3>
            <p className="mt-2 text-sm text-slate-200/70">reply rate · {metric.total_recipients} recipients</p>
            <p className="mt-1 text-xs text-slate-300/70">Influenced pipeline ${metric.influenced_pipeline.toLocaleString()}</p>
          </motion.article>
        ))}
      </div>
    </motion.section>
  );
}

export default MetricsDeck;
