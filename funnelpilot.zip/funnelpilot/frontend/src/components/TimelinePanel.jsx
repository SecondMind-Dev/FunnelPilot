import { motion } from "framer-motion";
import { Clock } from "lucide-react";

function TimelinePanel({ timeline }) {
  const recent = timeline.slice(-12).reverse();
  return (
    <motion.section
      initial={{ opacity: 0, x: 12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.4 }}
      className="rounded-3xl border border-slate-700/60 bg-slate-950/70 p-5 backdrop-blur"
    >
      <header className="flex items-center gap-2 text-slate-200">
        <Clock className="h-4 w-4 text-neon-teal" />
        <h2 className="text-sm uppercase tracking-[0.35em] text-slate-400">Channel timeline</h2>
      </header>
      <div className="mt-4 space-y-3">
        {recent.map((event, index) => (
          <motion.div
            key={`${event.campaign_id}-${index}`}
            initial={{ opacity: 0, x: 12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.03 }}
            className="rounded-2xl border border-slate-700/50 bg-slate-900/60 px-4 py-3"
          >
            <p className="text-xs uppercase tracking-widest text-slate-400">{event.channel}</p>
            <p className="text-sm text-slate-100">
              <span className="text-neon-teal">{event.recipient}</span> · {event.status}
            </p>
            <p className="text-xs text-slate-400">{new Date(event.timestamp ?? event.sent_at ?? Date.now()).toLocaleString()}</p>
          </motion.div>
        ))}
        {!recent.length && <p className="text-sm text-slate-400">No events yet — fire a campaign.</p>}
      </div>
    </motion.section>
  );
}

export default TimelinePanel;
