import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ScanFace } from "lucide-react";
import CampaignBoard from "./components/CampaignBoard.jsx";
import MetricsDeck from "./components/MetricsDeck.jsx";
import TimelinePanel from "./components/TimelinePanel.jsx";
import SequenceComposer from "./components/SequenceComposer.jsx";
import ChannelHeatmap from "./components/ChannelHeatmap.jsx";
import MissionConsole from "./components/MissionConsole.jsx";
import { useCampaigns } from "./hooks/useCampaigns.js";

function App() {
  const {
    segments,
    campaigns,
    metrics,
    timeline,
    runs,
    decisions,
    missionEvents,
    missionError,
    loading,
    error,
    planCampaign,
    launch,
    aiCopy,
  } = useCampaigns();

  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [launchingId, setLaunchingId] = useState(null);
  const [launchToast, setLaunchToast] = useState(null);

  useEffect(() => {
    if (!selectedCampaign && campaigns.length) {
      setSelectedCampaign(campaigns[0]);
    }
  }, [campaigns, selectedCampaign]);

  useEffect(() => {
    if (!selectedCampaign) return;
    const match = campaigns.find((camp) => camp.id === selectedCampaign.id);
    if (match && match.status !== selectedCampaign.status) {
      setSelectedCampaign(match);
    }
  }, [campaigns, selectedCampaign]);

  const runwayStats = useMemo(() => {
    if (!campaigns.length) return null;
    const launched = campaigns.filter((camp) => camp.status === "launched").length;
    return {
      total: campaigns.length,
      launched,
      queued: campaigns.length - launched,
    };
  }, [campaigns]);

  async function handlePlan(segmentId) {
    try {
      const plan = await planCampaign(segmentId);
      setSelectedCampaign(plan);
    } catch (err) {
      console.error(err);
    }
  }

  async function handleLaunch(campaignId) {
    setLaunchingId(campaignId);
    try {
      const response = await launch(campaignId);
      setAiSuggestion({
        title: "Campaign ignited",
        body: `${Math.round((response.metrics.reply_rate || 0) * 100)}% projected reply lift`,
      });
      if (response.decisions?.length) {
        setLaunchToast(response.decisions[0].decision?.title ?? "Heuristic fired");
      } else {
        setLaunchToast("Playbook synced 2h ago");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLaunchingId(null);
      setTimeout(() => setLaunchToast(null), 6000);
    }
  }

  async function handleCopySuggestion(campaign) {
    const prompt = `Craft a ${campaign.steps[0].channel} message for ${campaign.segment?.name ?? "this segment"}`;
    const suggestion = await aiCopy(prompt, "bold");
    setAiSuggestion({
      title: suggestion.subject || "AI Copy",
      body: suggestion.body,
    });
  }

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#0a0a0f] via-[#0f0f24] to-[#1a1a2f] text-slate-50">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-10">
        <motion.header
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl border border-neon-royal/40 bg-gradient-to-r from-slate-950/80 via-slate-900/60 to-slate-950/80 p-6 shadow-lg shadow-purple-900/40"
        >
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.35em] text-neon-teal/70">Second Mind Ops</p>
              <h1 className="mt-1 text-3xl font-semibold">FunnelPilot Command Cockpit</h1>
              <p className="mt-2 max-w-xl text-sm text-slate-300/80">
                Pull segments from every CRM, sculpt a multi-channel sequence, then launch and watch the funnel glow.
              </p>
            </div>
            {runwayStats && (
              <div className="rounded-2xl border border-neon-teal/40 bg-neon-teal/10 px-4 py-3 text-sm text-neon-teal">
                {runwayStats.launched} launched · {runwayStats.queued} queued
              </div>
            )}
          </div>
        </motion.header>

        {error && (
          <div className="rounded-2xl border border-red-600/40 bg-red-500/10 px-4 py-3 text-sm text-red-200">
            {error}
          </div>
        )}
        {loading && <p className="text-sm text-slate-400">Synthesizing campaign intelligence…</p>}

        <CampaignBoard
          segments={segments}
          campaigns={campaigns}
          onPlan={handlePlan}
          onLaunch={handleLaunch}
          selectedCampaignId={selectedCampaign?.id}
          onSelect={setSelectedCampaign}
          launchingId={launchingId}
        />

        <div className="grid gap-5 lg:grid-cols-[2fr_1fr]">
          <SequenceComposer campaign={selectedCampaign} onCopySuggestion={handleCopySuggestion} />
          <TimelinePanel timeline={timeline} />
        </div>

        <MetricsDeck metrics={metrics} />

        <ChannelHeatmap campaigns={campaigns} />

        <MissionConsole missions={decisions.length ? decisions : missionEvents} runs={runs} />

        {missionError && (
          <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-xs text-amber-200">
            {missionError}
          </div>
        )}

        {aiSuggestion && (
          <motion.aside
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-start gap-3 rounded-3xl border border-neon-magenta/50 bg-neon-magenta/10 p-4"
          >
            <ScanFace className="mt-1 h-6 w-6 text-neon-magenta" />
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-widest text-neon-magenta/80">{aiSuggestion.title}</h3>
              <p className="mt-1 text-sm text-slate-100 whitespace-pre-line">{aiSuggestion.body}</p>
            </div>
          </motion.aside>
        )}

        {launchToast && (
          <motion.aside
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-6 right-6 flex items-center gap-3 rounded-2xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200"
          >
            <span className="text-xs uppercase tracking-widest text-emerald-200/80">Mission update</span>
            <span>{launchToast}</span>
          </motion.aside>
        )}
      </div>
    </main>
  );
}

export default App;
