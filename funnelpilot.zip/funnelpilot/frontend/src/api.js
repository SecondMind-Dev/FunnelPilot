const API_BASE = import.meta.env.VITE_FUNNELPILOT_API || "http://127.0.0.1:8002";

async function jsonRequest(path, opts = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`API ${path} failed: ${detail}`);
  }
  return response.json();
}

export async function fetchSegments() {
  const data = await jsonRequest("/segments");
  return data;
}

export async function createCampaign(payload) {
  return jsonRequest("/campaigns", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function fetchCampaigns() {
  return jsonRequest("/campaigns");
}

export async function launchCampaign(id, useAI = true) {
  return jsonRequest(`/campaigns/${id}/launch`, {
    method: "POST",
    body: JSON.stringify({ use_ai: useAI }),
  });
}

export async function fetchAnalytics() {
  const [payload] = await jsonRequest("/analytics/kpis");
  return payload;
}

export async function fetchMissionEvents(since) {
  const query = since ? `?since=${encodeURIComponent(since)}` : "";
  return jsonRequest(`/mission-events${query}`);
}

export async function requestCopy(prompt, tone = "bold") {
  return jsonRequest("/copy/suggest", {
    method: "POST",
    body: JSON.stringify({ prompt, tone }),
  });
}

export async function fetchTimeline() {
  return jsonRequest("/timeline");
}
