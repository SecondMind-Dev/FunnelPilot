import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/ui",
  timeout: 90 * 1000,
  use: {
    baseURL: "http://localhost:4174",
    headless: true,
  },
});
