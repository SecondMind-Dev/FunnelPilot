import { render, screen } from "@testing-library/react";
import MissionConsole from "../../src/components/MissionConsole.jsx";

const missions = [
  {
    id: "cmp-123-cadence-delay",
    decision: { title: "Audience cooling", detail: "Cooling off", intensity: 0.7 },
    timestamp: new Date().toISOString(),
  },
];

const runs = [
  {
    campaign_id: "cmp-123",
    started_at: new Date().toISOString(),
    completed_at: new Date().toISOString(),
    delivered: 10,
    responses: 4,
  },
];

describe("MissionConsole", () => {
  it("renders decisions", () => {
    render(<MissionConsole missions={missions} runs={runs} />);
    expect(screen.getByText(/Audience cooling/)).toBeInTheDocument();
  });

  it("renders placeholder when empty", () => {
    render(<MissionConsole missions={[]} runs={[]} />);
    expect(screen.getByText(/No missions fired yet/)).toBeInTheDocument();
  });
});
