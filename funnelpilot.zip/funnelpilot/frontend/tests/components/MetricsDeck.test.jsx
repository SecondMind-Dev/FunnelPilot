import { render } from "@testing-library/react";
import MetricsDeck from "../../src/components/MetricsDeck.jsx";

const metrics = [
  {
    campaign_id: "cmp-1",
    total_recipients: 42,
    open_rate: 0.44,
    reply_rate: 0.33,
    meetings_booked: 3,
    influenced_pipeline: 2400,
  },
];

describe("MetricsDeck", () => {
  it("matches snapshot", () => {
    const { asFragment } = render(<MetricsDeck metrics={metrics} />);
    expect(asFragment()).toMatchSnapshot();
  });
});
