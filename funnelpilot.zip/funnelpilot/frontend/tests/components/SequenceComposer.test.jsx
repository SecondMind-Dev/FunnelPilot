import { render, screen } from "@testing-library/react";
import SequenceComposer from "../../src/components/SequenceComposer.jsx";

const campaign = {
  id: "cmp-demo",
  name: "Demo Campaign",
  steps: [
    { order: 1, channel: "email", subject: "Hello", body: "Body copy", send_offset_hours: 0, call_to_action: "Reply" },
  ],
};

describe("SequenceComposer", () => {
  it("renders campaign steps", () => {
    render(<SequenceComposer campaign={campaign} onCopySuggestion={vi.fn()} />);
    expect(screen.getByText("Demo Campaign")).toBeInTheDocument();
    expect(screen.getByText(/Body copy/)).toBeInTheDocument();
  });

  it("renders placeholder when no campaign selected", () => {
    render(<SequenceComposer campaign={null} onCopySuggestion={vi.fn()} />);
    expect(screen.getByText(/Choose a campaign/)).toBeInTheDocument();
  });
});
