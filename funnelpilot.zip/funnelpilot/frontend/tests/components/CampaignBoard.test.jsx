import { render, screen, fireEvent } from "@testing-library/react";
import CampaignBoard from "../../src/components/CampaignBoard.jsx";

const segments = [
  {
    id: "hs-growth-ops",
    name: "HubSpot Growth",
    crm: "hubspot",
    description: "Growth personas",
    size: 42,
  },
];

const campaigns = [
  {
    id: "cmp-123",
    name: "HubSpot Growth",
    goal: "Book demos",
    owner: "Caleb",
    status: "scheduled",
    steps: [],
  },
];

describe("CampaignBoard", () => {
  it("renders segments and allows planning", () => {
    const onPlan = vi.fn();
    render(
      <CampaignBoard
        segments={segments}
        campaigns={campaigns}
        onPlan={onPlan}
        onLaunch={vi.fn()}
        selectedCampaignId="cmp-123"
        onSelect={vi.fn()}
        launchingId={null}
      />
    );

    const headings = screen.getAllByRole("heading", { name: /HubSpot Growth/i });
    expect(headings.length).toBeGreaterThan(0);
    fireEvent.click(screen.getAllByText(/Prime playbook/i)[0]);
    expect(onPlan).toHaveBeenCalledWith("hs-growth-ops");
  });
});
