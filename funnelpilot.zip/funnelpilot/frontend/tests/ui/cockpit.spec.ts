import { test, expect } from "@playwright/test";

const TEMPLATE = `
  <main data-testid="cockpit" style="background: linear-gradient(180deg,#0a0a0f,#1a1a2f); min-height: 100vh; color: #e0e0f0; display: flex; align-items: center; justify-content: center;">
    <section style="border: 2px solid rgba(111,0,255,0.6); border-radius: 24px; background: rgba(17,17,34,0.8); padding: 2.5rem 3rem; text-align:center; box-shadow: 0 0 25px rgba(111,0,255,0.3);">
      <h1 class="text-3xl font-semibold tracking-[0.35em] uppercase">FunnelPilot</h1>
      <p class="mt-4 text-sm text-slate-300">Neon theatre check — this replicates the Command Cockpit hero.</p>
    </section>
  </main>
`;

test("neon cockpit has gradient backdrop", async ({ page }) => {
  await page.setContent(TEMPLATE, { waitUntil: "domcontentloaded" });
  const gradient = await page.$eval("[data-testid='cockpit']", (element) =>
    window.getComputedStyle(element).backgroundImage
  );
  expect(gradient).toContain("linear-gradient");
  const borderColor = await page.$eval("section", (element) =>
    window.getComputedStyle(element).borderColor
  );
  expect(borderColor).toMatch(/111, 0, 255/);
});
