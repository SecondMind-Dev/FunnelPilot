module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        neon: {
          teal: "#00ffe0",
          magenta: "#ff00aa",
          royal: "#6f00ff",
        },
      },
      backgroundImage: {
        "starfield": "radial-gradient(circle at top, rgba(111,0,255,0.25), transparent 60%)",
      },
    },
  },
  plugins: [],
};
