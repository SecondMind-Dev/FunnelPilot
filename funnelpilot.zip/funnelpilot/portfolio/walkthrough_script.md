# FunnelPilot Loom Narration (60s)

**Opening (0-10s)**
- “Hey, it’s Caleb. This is FunnelPilot — my neon cockpit for multi-channel campaigns.”
- Hover over the hero cards while noting the CRM badges.

**Segment Planning (10-25s)**
- Click a HubSpot segment. “These audiences come straight from HubSpot, Salesforce, and Pipedrive. One click primes a full playbook.”
- Hit “Prime playbook” and show the plan appearing on the board.

**AI Copy Assist (25-35s)**
- Open the sequence drawer. “Each step is pre-templated, but I can hit ‘Ask AI’ to remix tone instantly.”
- Trigger AI suggestion; read the new subject line.

**Launch + Webhook (35-45s)**
- Press “Ignite now.” “Scheduler spins up, pushes email + LinkedIn, and pipes a Slack digest so the team gets the hype.”
- Flash the Slack artifact or CLI output.

**Analytics Wrap (45-60s)**
- Scroll to KPI deck + heatmap. “FunnelPilot re-scores leads after every send, so hot prospects jump back into HelixScore. It’s a closed loop for marketing ops.”
- End with the URL and invite them to explore the live deploy.
