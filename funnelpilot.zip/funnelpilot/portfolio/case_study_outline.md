# FunnelPilot Case Study Outline

1. **Challenge** – Mid-market SaaS teams juggle fragmented CRMs and disconnected outreach channels.
2. **Approach** – Unified connectors pull live segments; AI-assisted sequence builder scripts email, LinkedIn, and SMS; scheduler auto-launches every 6h.
3. **Execution Highlights**
   - Segmentation snapshots across HubSpot, Salesforce, Pipedrive.
   - Dynamic copy remix with GPT fallback for deterministic demos.
   - Slack/LinkedIn channel logs for stakeholder alignment.
4. **Results** (hypothetical demo metrics)
   - 32% lift in SQL velocity over a two-week pilot.
   - 2.3x reply rate after multi-channel orchestration.
   - 18% increase in product-led activation via targeted SMS.
5. **Artifacts** – Dashboard screenshot, Slack digest, KPI chart, Loom walkthrough.
6. **Next Steps** – Connect marketing automation hooks (Marketo, Iterable) and push-failover monitoring.
