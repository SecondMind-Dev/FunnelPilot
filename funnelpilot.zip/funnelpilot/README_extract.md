# FunnelPilot Quickstart

```bash
# clone the repo
 git clone https://github.com/<your-handle>/funnelpilot.git
 cd funnelpilot

# backend deps
 pip install -r requirements.txt

# frontend deps
 cd frontend && npm install && cd ..

# run both servers
 ./scripts/run_funnel.sh
```

- Backend API: http://localhost:8002
- Frontend UI: http://localhost:5174

Set environment variables in `.env`:
```
HUBSPOT_API_KEY=...
SALESFORCE_API_KEY=...
PIPEDRIVE_API_KEY=...
SLACK_WEBHOOK_URL=...
OPENAI_API_KEY=...
```
- Optional portfolio recap: run `./scripts/generate_report.py` to refresh `portfolio/reports/latest_report.html`.
