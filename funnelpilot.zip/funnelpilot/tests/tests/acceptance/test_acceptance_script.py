from __future__ import annotations

from fastapi.testclient import TestClient


def test_acceptance_campaign_workflow(client: TestClient) -> None:
    segments = client.get("/segments").json()
    assert segments, "Segments must exist for acceptance"

    plan = client.post("/campaigns", json={"segment_id": segments[0]["id"], "goal": "Book meetings"}).json()
    assert plan["status"] in {"draft", "scheduled"}

    launch = client.post(f"/campaigns/{plan['id']}/launch", json={"use_ai": True}).json()
    assert launch["status"] == "ok"
    assert launch["events"], "Campaign should produce channel events"
