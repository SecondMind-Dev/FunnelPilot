from __future__ import annotations

from fastapi.testclient import TestClient


def test_service_health_returns_timestamp(client: TestClient) -> None:
    response = client.get("/health")
    payload = response.json()
    assert payload["timestamp"]
    assert isinstance(payload["active_connectors"], list)
