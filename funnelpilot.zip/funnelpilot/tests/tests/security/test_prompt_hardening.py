from __future__ import annotations

from funnelpilot.backend.utils.templates import ai_suggest_copy


def test_ai_copy_handles_injection(monkeypatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    suggestion = ai_suggest_copy("\n\nDROP TABLE leads; --")
    assert "drop" not in suggestion.body.lower()
