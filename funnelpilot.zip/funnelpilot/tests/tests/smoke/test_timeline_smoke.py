from __future__ import annotations

from fastapi.testclient import TestClient


def test_timeline_endpoint(client: TestClient) -> None:
    response = client.get("/timeline")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
