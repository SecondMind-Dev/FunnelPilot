from __future__ import annotations

import os
from collections.abc import Generator
from typing import Any

import pytest
from fastapi.testclient import TestClient

from funnelpilot.backend.main import app
from funnelpilot.backend.campaigns.scheduler import stop_scheduler
from funnelpilot.backend.utils import store

DATA_FILES = [
    "segments.json",
    "channel_logs.json",
    "campaign_runs.json",
    "schedule.json",
    "ai_copy_cache.json",
]


@pytest.fixture(autouse=True)
def _env_guard(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FUNNELPILOT_ENABLE_SCHEDULER", "0")
    monkeypatch.setenv("OPENAI_API_KEY", "")
    monkeypatch.setenv("SLACK_WEBHOOK_URL", "")
    monkeypatch.setenv("TEAMS_WEBHOOK_URL", "")


@pytest.fixture()
def restore_data() -> Generator[None, None, None]:
    snapshots: dict[str, Any] = {}
    for name in DATA_FILES:
        snapshots[name] = store.load_json(name, default=[])
    yield
    for name, payload in snapshots.items():
        store.write_json(name, payload)


@pytest.fixture()
def client(restore_data: None) -> Generator[TestClient, None, None]:
    with TestClient(app) as test_client:
        yield test_client
    stop_scheduler()
