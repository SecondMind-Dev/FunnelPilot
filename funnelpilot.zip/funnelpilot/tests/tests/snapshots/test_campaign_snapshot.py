from __future__ import annotations

import json
from pathlib import Path

from funnelpilot.backend.campaigns.sequence import build_campaign_plan
from funnelpilot.backend.services.segmentation import list_segments

SNAPSHOT = Path(__file__).resolve().parent / "campaign_plan.json"


def test_campaign_plan_snapshot(restore_data) -> None:
    segment = list_segments()[0]
    plan = build_campaign_plan(segment, owner="Caleb", goal="Book demos")
    payload = plan.model_dump(mode="json")
    payload["id"] = "<dynamic>"
    payload["created_at"] = "<timestamp>"
    payload["updated_at"] = "<timestamp>"
    if payload.get("scheduled_for"):
        payload["scheduled_for"] = "<timestamp>"

    expected = json.loads(SNAPSHOT.read_text())
    assert payload == expected
