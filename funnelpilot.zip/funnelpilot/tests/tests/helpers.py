from __future__ import annotations

import os
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRONTEND_DIR = PROJECT_ROOT / "frontend"
BACKEND_DIR = PROJECT_ROOT / "backend"

def ensure_frontend_dependencies() -> None:
    node_modules = FRONTEND_DIR / "node_modules"
    if not node_modules.exists():
        subprocess.run(["npm", "install"], cwd=FRONTEND_DIR, check=True)


def run_frontend(command: list[str]) -> subprocess.CompletedProcess[str]:
    ensure_frontend_dependencies()
    return subprocess.run(command, cwd=FRONTEND_DIR, check=True, capture_output=True, text=True)


def run_backend(command: list[str]) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env.setdefault("FUNNELPILOT_ENABLE_SCHEDULER", "0")
    return subprocess.run(command, cwd=BACKEND_DIR, env=env, check=True, capture_output=True, text=True)


def api_base() -> str:
    return os.environ.get("FUNNELPILOT_API", "http://127.0.0.1:8002")
