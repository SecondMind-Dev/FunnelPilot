from __future__ import annotations

import time

from funnelpilot.backend.services.segmentation import list_segments
from funnelpilot.backend.campaigns.sequence import build_campaign_plan
from funnelpilot.backend.services.delivery import launch_campaign


def test_launch_campaign_under_one_second(restore_data) -> None:
    segment = list_segments()[0]
    plan = build_campaign_plan(segment, owner="Caleb", goal="Book demos")
    start = time.perf_counter()
    launch_campaign(plan)
    elapsed = time.perf_counter() - start
    assert elapsed < 1.0
