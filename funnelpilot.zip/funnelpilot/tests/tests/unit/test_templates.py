from __future__ import annotations

from funnelpilot.backend.utils.templates import ai_suggest_copy


def test_ai_suggest_copy_returns_fallback_without_key(monkeypatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    suggestion = ai_suggest_copy("Write a hype email")
    assert "hype" in suggestion.body.lower()
    assert suggestion.model == "funnelpilot-fallback"
