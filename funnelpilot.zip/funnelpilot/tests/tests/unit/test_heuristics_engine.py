from __future__ import annotations

from datetime import datetime, timezone

from funnelpilot.backend.schemas.models import CampaignMetrics
from funnelpilot.backend.services.heuristics import record_heuristic_actions, mission_feed
from funnelpilot.backend.services.segmentation import list_segments
from funnelpilot.backend.utils.store import write_json


def test_record_heuristic_actions_captures_decision(restore_data) -> None:
    segment = list_segments()[0]
    metrics = CampaignMetrics(
        campaign_id="cmp-test",
        total_recipients=12,
        open_rate=0.32,
        reply_rate=0.27,
        meetings_booked=2,
        influenced_pipeline=4200,
    )
    plan = segment
    # mimic campaign plan
    from funnelpilot.backend.campaigns.sequence import build_campaign_plan

    plan_model = build_campaign_plan(segment, owner="Echo", goal=segment.persona, ai_assist=True)
    write_json("mission_events.json", [])

    decisions = record_heuristic_actions(plan_model, metrics)
    assert decisions, "Expected at least one heuristic decision"

    feed = mission_feed(None)
    assert isinstance(feed, list)
    assert feed
