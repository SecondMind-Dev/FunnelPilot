from __future__ import annotations

from datetime import datetime, timezone

from funnelpilot.backend.campaigns.sequence import build_campaign_plan
from funnelpilot.backend.schemas.models import Segment


def test_build_campaign_plan_generates_three_steps() -> None:
    segment = Segment(
        id="demo",
        name="Demo",
        crm="hubspot",
        description="",
        persona="growth",
        size=10,
        filters={},
        contacts=[],
        last_synced=datetime.now(timezone.utc),
    )

    plan = build_campaign_plan(segment, owner="Caleb", goal="Book demos", ai_assist=True)

    assert len(plan.steps) == 3
    assert plan.status == "scheduled"
    assert plan.ai_assist_enabled is True
