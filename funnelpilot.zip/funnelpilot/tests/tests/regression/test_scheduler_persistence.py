from __future__ import annotations

from funnelpilot.backend.campaigns.scheduler import schedule_campaign, scheduled_campaigns
from funnelpilot.backend.campaigns.sequence import build_campaign_plan
from funnelpilot.backend.services.segmentation import list_segments


def test_schedule_roundtrip(restore_data) -> None:
    segment = list_segments()[0]
    plan = build_campaign_plan(segment, owner="Echo", goal="Test persistence")
    schedule_campaign(plan)
    stored = scheduled_campaigns()
    assert any(item.id == plan.id for item in stored)
