from __future__ import annotations

from fastapi.testclient import TestClient


def test_health_contract(client: TestClient) -> None:
    response = client.get("/health")
    payload = response.json()
    assert set(payload.keys()) == {"status", "timestamp", "scheduler_up", "pending_campaigns", "active_connectors", "docs_url"}
    assert payload["status"] == "ok"
