from __future__ import annotations

from fastapi.testclient import TestClient


def test_end_to_end_campaign_flow(client: TestClient) -> None:
    seg_resp = client.get("/segments")
    segment_id = seg_resp.json()[0]["id"]
    plan_resp = client.post("/campaigns", json={"segment_id": segment_id, "owner": "Echo"})
    plan_resp.raise_for_status()
    campaign_id = plan_resp.json()["id"]

    launch_resp = client.post(f"/campaigns/{campaign_id}/launch", json={"use_ai": True})
    launch_resp.raise_for_status()

    analytics = client.get("/analytics/kpis").json()
    assert analytics[0]["metrics"]
    assert analytics[0]["timeline"]
