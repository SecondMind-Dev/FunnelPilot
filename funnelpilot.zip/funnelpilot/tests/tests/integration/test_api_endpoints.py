from __future__ import annotations

from fastapi.testclient import TestClient


def test_segments_endpoint(client: TestClient) -> None:
    response = client.get("/segments")
    assert response.status_code == 200
    payload = response.json()
    assert isinstance(payload, list)
    assert payload and "name" in payload[0]


def test_campaign_lifecycle(client: TestClient) -> None:
    segments = client.get("/segments").json()
    segment_id = segments[0]["id"]
    created = client.post("/campaigns", json={"segment_id": segment_id, "owner": "Caleb"}).json()
    assert created["segment_id"] == segment_id
    launched = client.post(f"/campaigns/{created['id']}/launch", json={"use_ai": True})
    assert launched.status_code == 200
    body = launched.json()
    assert body["status"] == "ok"
    assert body["metrics"]["reply_rate"] >= 0



def test_mission_events_endpoint(client: TestClient) -> None:
    response = client.get("/mission-events")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
