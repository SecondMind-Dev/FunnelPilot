from __future__ import annotations

from funnelpilot.backend.services.segmentation import list_segments
from funnelpilot.backend.campaigns.sequence import build_campaign_plan
from funnelpilot.backend.services.delivery import launch_campaign


def test_campaign_launch_generates_events(restore_data) -> None:
    segment = list_segments()[0]
    plan = build_campaign_plan(segment, owner="Caleb", goal="Book demos", ai_assist=True)
    result = launch_campaign(plan)

    assert result["metrics"]["reply_rate"] >= 0
    assert len(result["events"]) >= len(segment.contacts)
