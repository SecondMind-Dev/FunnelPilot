# FunnelPilot Deployment Cheatsheet

## Render.com

1. Create a new **Web Service** from your GitHub repo pointing to the `funnelpilot` folder.
2. Use the following settings:
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn funnelpilot.backend.main:app --host 0.0.0.0 --port 8002`
   - Python version: 3.12
3. Provide the required environment variables (`HUBSPOT_API_KEY`, `SALESFORCE_API_KEY`, `PIPEDRIVE_API_KEY`, `SLACK_WEBHOOK_URL`, `OPENAI_API_KEY`).
4. Disable auto-deploy until manual QA is complete.

## Fly.io

1. Install `flyctl` and run `fly launch --no-deploy` from the `funnelpilot` directory.
2. Review and tweak `deploy/fly.toml` if you need a different region or scaling plan.
3. Deploy with `fly deploy`.

## Docker

```
cd funnelpilot
docker build -t funnelpilot:latest -f deploy/Dockerfile .
docker run -p 8002:8002 funnelpilot:latest
```

## Frontend Hosting

The React frontend is Vite-based. Build assets with `npm run build` and deploy the generated `dist/` folder to Netlify, Vercel, or Render Static Sites. Point the frontend to the backend URL via `VITE_FUNNELPILOT_API` env variable.
