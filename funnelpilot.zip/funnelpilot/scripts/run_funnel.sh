#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
API_PORT=${API_PORT:-8002}
WEB_PORT=${WEB_PORT:-5174}
PYTHON_BIN="${ROOT_DIR}/.venv/bin/python"

if [[ ! -x "${PYTHON_BIN}" ]]; then
  PYTHON_BIN=$(command -v python3)
fi

kill_port() {
  local port=$1
  if command -v lsof >/dev/null; then
    local pids
    pids=$(lsof -t -i tcp:${port} || true)
    if [[ -n "${pids}" ]]; then
      echo "[funnelpilot] freeing port ${port} (PIDs: ${pids})"
      kill ${pids} 2>/dev/null || true
    fi
  fi
}

kill_port "${API_PORT}"
kill_port "${WEB_PORT}"

pushd "${ROOT_DIR}/funnelpilot/frontend" >/dev/null
if [[ ! -d node_modules ]]; then
  echo "[funnelpilot] Installing frontend dependencies..."
  npm install >/dev/null
fi
popd >/dev/null

cleanup() {
  trap - INT TERM EXIT
  if [[ -n "${BACK_PID:-}" ]]; then
    kill "${BACK_PID}" 2>/dev/null || true
  fi
  if [[ -n "${WEB_PID:-}" ]]; then
    kill "${WEB_PID}" 2>/dev/null || true
  fi
}
trap cleanup INT TERM EXIT

FUNNEL_ENV=("FUNNELPILOT_ENABLE_SCHEDULER=${FUNNELPILOT_ENABLE_SCHEDULER:-1}")
${PYTHON_BIN} -m uvicorn funnelpilot.backend.main:app --reload --host 0.0.0.0 --port "${API_PORT}" &
BACK_PID=$!

echo "[funnelpilot] backend booted on ${API_PORT}"

pushd "${ROOT_DIR}/funnelpilot/frontend" >/dev/null
npm run dev -- --host 0.0.0.0 --port "${WEB_PORT}" &
WEB_PID=$!
popd >/dev/null

echo
echo "FunnelPilot running:" 
echo "  • API: http://localhost:${API_PORT}"
echo "  • UI : http://localhost:${WEB_PORT}"
echo "Press Ctrl+C to stop twin engines."
echo

wait "${BACK_PID}" "${WEB_PID}"
