#!/usr/bin/env python3
"""Generate a portfolio-ready mission recap HTML using latest data."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from jinja2 import Environment, FileSystemLoader

from funnelpilot.backend.schemas.models import CampaignMetrics
from funnelpilot.backend.services.analytics import historical_kpis, load_runs
from funnelpilot.backend.services.heuristics import mission_feed
from funnelpilot.backend.utils.store import load_json as store_load_json

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "portfolio" / "reports"
OUTPUT_DIR = TEMPLATE_DIR
DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def load_channel_timeline() -> list[dict[str, str]]:
    timeline_path = DATA_DIR / "channel_logs.json"
    if not timeline_path.exists():
        return []
    try:
        return store_load_json("channel_logs.json", default=[])
    except Exception:  # noqa: BLE001
        return []


def latest_campaign_id() -> str:
    runs = load_runs()
    if not runs:
        return "n/a"
    return runs[-1].campaign_id


def metrics_cards(metrics: list[CampaignMetrics]) -> list[dict[str, str]]:
    if not metrics:
        return []
    latest = metrics[-1]
    return [
        {"title": "Reply rate", "value": f"{latest.reply_rate * 100:.1f}%"},
        {"title": "Open rate", "value": f"{latest.open_rate * 100:.1f}%"},
        {"title": "Influenced pipeline", "value": f"${latest.influenced_pipeline:,.0f}"},
        {"title": "Meetings booked", "value": str(latest.meetings_booked)},
    ]


def main() -> None:
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))
    template = env.get_template("report_template.html")

    metrics = historical_kpis()
    decisions = mission_feed(None)
    timeline = load_channel_timeline()[-25:]
    payload = {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M"),
        "campaign_id": latest_campaign_id(),
        "metrics": metrics_cards(metrics),
        "decisions": decisions[-10:],
        "timeline": timeline,
    }

    html = template.render(**payload)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / "latest_report.html"
    output_path.write_text(html, encoding="utf-8")
    print(f"Report generated → {output_path}")


if __name__ == "__main__":
    main()
